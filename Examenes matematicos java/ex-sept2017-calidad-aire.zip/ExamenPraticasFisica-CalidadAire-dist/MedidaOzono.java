
/**
 * Almacena los datos de la medida de ozono superficial para un dia concreto
 * 
 * @author (Michael) 
 * @version (jul 2017)
 */
public class MedidaOzono
{
    // 
    private double ozono; //concentracion de ozono en ug/m3
    private double radSolar; // radiacion solar en W/m2, 
    private double viento; // velocidad del viento en m/s, 
    private double temp; // temperatura en C
    private int mes; // el mes de la medida (entre 1 y 12) 
    private int dia; // el dia de la medida (entre 1 y 31);

    /**
     * Constructor al que se le pasan los valores iniciales de los
     * atributos: concentracion de ozono en mg/m3, radiacion solar
     * en W/m2, velocidad del viento en m/s, temperatura en C y el
     * mes (entre 1 y 12) y dia (entre 1 y 31) de la medida
     */
    public MedidaOzono(double ozono, double radSolar, double viento, 
		       double temp, int mes, int dia)
    {
        this.ozono=ozono;
        this.radSolar=radSolar;
        this.viento=viento;
        this.temp=temp;
        this.mes=mes;
        this.dia=dia;
    }

    /**
     * Retorna la concentracion de ozono
     * 
     * @return     concentracion de ozono en ug/m3
     */
    public double getOzono()
    {
        return ozono;
    }

    /**
     * Retorna la radiacion solar
     * 
     * @return     radiacion solar en W/m2
     */
    public double getRadSolar()
    {
        return radSolar;
    }

    /**
     * Retorna la velocidad del viento
     * 
     * @return     velocidad del viento en m/s
     */
    public double getViento()
    {
        return viento;
    }

    /**
     * Retorna la temperatura
     * 
     * @return     temperatura en C
     */
    public double getTemp()
    {
        return temp;
    }

    /**
     * Retorna el mes de la observacion
     * 
     * @return     Mes de la observacion entre 1 y 12
     */
    public int getMes()
    {
        return mes;
    }

    /**
     * Retorna el dia de la observacion
     * 
     * @return     dia de la observacion entre 1 y 31
     */
    public int getDia()
    {
        return dia;
    }
    
    
}
