import java.util.*;
import java.io.*;
import fundamentos.*;

/**
 * Clase que recoge en un ArrayList una lista con los datos de varias 
 * medidas de ozono almacenadas en objetos de la clase MedidaOzono, 
 * ordenadas por fecha de menor a mayor
 * 
 * @author (Michael) 
 * @version (jul 2017)
 */
public class CalidadAire
{
    private ArrayList<MedidaOzono> lista;
    private int anyo;

    /**
     * Constructor que lee de un fichero en formato csv los datos de
     * las medidas de la calidad del aire
     * 
     * @param nombreFich el nombre del fichero
     * @throws FileNotFoundException el fichero no existe
     * @throws ErrorDeFormato el formato del fichero csv es incorrecto
     */
    public CalidadAire(String nombreFich) throws 
	FileNotFoundException, ErrorDeFormato
    {
        lista=new ArrayList<MedidaOzono>();
        try (Scanner in= new Scanner(new FileReader(nombreFich)))
        {
            //ignoramos la primera linea
            in.nextLine();
            // Lee una linea con el anyo
            String linea=in.nextLine();
            // Parte la linea por las ','
            String[] elem=linea.split(",");
            this.anyo=Integer.parseInt(elem[1]);
            
            // lee el resto del fichero linea a linea
            while (in.hasNextLine()) {
                try {
                    // lee la siguiente linea 
                    linea=in.nextLine();
                    // Parte la linea por las ','
                    elem=linea.split(",");
                    // Crea una MedidaOzono y la anade a la lista
                    double ozono=Double.parseDouble(elem[1]);
                    double radSolar=Double.parseDouble(elem[2]);
                    double viento=Double.parseDouble(elem[3]);
                    double temp=Double.parseDouble(elem[4]);
                    int mes=Integer.parseInt(elem[5]);
                    int dia=Integer.parseInt(elem[6]);
                    this.lista.add
			(new MedidaOzono(ozono,radSolar,viento,temp,mes,dia));
                } catch(NumberFormatException e) {
                    // ignorar errores de formato de numero
                }
            }
        } catch (IOException | NoSuchElementException |
		 ArrayIndexOutOfBoundsException e) 
        {
            throw new ErrorDeFormato(); 
        }
        
    }
    
    

    /**
     * Compara todas las parejas de medidas consecutivas del conjunto
     * de medidas, buscando aquella en la que la variacion en la
     * cantidad de ozono sea mayor, independientemente de que sea un
     * ascenso o un descenso de dicha cantidad.
     * 
     * @return el objeto conteniendo la segunda de las dos medidas
     *           comparadas cuya variacion es maxima.  null si hay
     *           menos de dos medidas en la lista
     */
    public MedidaOzono maximaVariacionOzono()
    {
       //TO DO. A hacer por el alumno  
       return null;
    }

    
    /**
     * Retorna todas las medidas registradas cuya cantidad de ozono
     * esta por encima del umbral que se recibe como parametro. En
     * caso de que no haya ninguna medida que cumpla la condicion se
     * devuelve null.
     * 
     * @param umbralOzono umbral de referencia para determinar las
     *           medidas a retornar
     * @return array con todas las medidas registradas cuya cantidad
     *           de ozono esta por encima del umbral recibido.  null
     *           si no hay ninguna
     */
    public MedidaOzono[] picos(double umbralOzono)
    {
         //TO DO. A hacer por el alumno  
        return null;
    }
    
    
    /**
     * Muestra una ventana en la que se muestran 2 graficas: una que
     * muestra la cantidad de ozono en cada dia de de un mes
     * determinado y otra que muestra otra de las magnitudes que
     * intervienen en las mediciones (viento, radiacion o temperatura)
     * en esos mismos dias.
     * 
     * La magnitud a mostrar se determina mediante un parametro que
     * indica el nombre de la magnitud Si no se especifica
     * correctamente el mes o la magnitud, se lanzan sendas
     * excepciones.
     * 
     * @param magnitud el nombre de la magnitud a mostrar junto con el
     *           nivel de ozono.
     * @param    mes        el mes que se muestra en la grafica
     * 
     * @throws MagnitudIncorrecta si no se indica correctamente la
     *                              magnitud a mostrar (viento,
     *                              radiacion o temperatura)
     * @throws MesIncorrecto si el mes facilitado no es correcto
     *                              (entre 1 y 12)
     */
    public void comparativaOzonoMagnitudPorMes(String magnitud,int mes)throws 
	MagnitudIncorrecta, MesIncorrecto
    {
         //TO DO. A hacer por el alumno  
    }
   
}
