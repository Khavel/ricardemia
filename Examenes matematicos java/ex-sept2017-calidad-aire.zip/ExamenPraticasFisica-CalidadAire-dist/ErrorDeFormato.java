
/**
 * Hay un error de formato en el fichero CSV
 * 
 * @author (Michael) 
 * @version (jun 2017)
 */
public class ErrorDeFormato extends Exception {}
