
/**
 * Excepcion que indica que el indice de la lista es menor que cero o
 * mayor o igual que el tamano de la lista
 * 
 * @author (Michael) 
 * @version (jun 2017)
 */
public class IndiceIncorrecto extends Exception {}
