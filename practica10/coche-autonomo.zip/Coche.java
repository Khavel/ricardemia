import java.util.ArrayList;
import java.util.Scanner;
import java.util.Locale;
import java.io.*;
import fundamentos.Dibujo;
import fundamentos.ColorFig;
/**
 * Clase para simular y probar el funcionamiento del sistema de
 * deteccion de colisiones
 */
public class Coche {

    private ArrayList<Obstaculo> lista; //una lista de obstaculos
    private double vC;                  // velocidad del coche en m/s
    private final double A,L;           // dimensiones del coche 
                                        // (semianchura y longitud) en m
    /**
     * Constructor que recibe como parametros la velocidad del coche
     * vC en m/s, las dimensiones A y L del coche en m y el nombre de
     * un fichero de texto del que se leen datos para rellenar la
     * lista de obstaculos
     * 
     * @param vC velocidad del coche, m/s
     * @param A  semianchura del coche, m
     * @paral L longitud del coche, m
     * @param nombreFichero el nombre del fichero de texto del que se lee 
     *                      la lista de obstaculos a probar
     */
    public Coche(double vC, double A, double L, String nombreFichero) {
        // Copiamos los atributos
        this.vC = vC;
        this.A = A;
        this.L = L;
        // Creamos la lista de obtaculos vacia
        lista = new ArrayList<Obstaculo>();
        // Abrimos el fichero para leer
        try (Scanner in=new Scanner(new FileReader(nombreFichero))) {
            // Ponemos la convencion de lectura de numeros a ingles
            in.useLocale(Locale.ENGLISH);
            int id;
            double vT,vN,d,alfa,r;
            // Saltarse la primera linea del fichero
            in.nextLine();
            // Bucle mientras haya mas datos por leer
            while (in.hasNext()) {
                // leer los datos de un obstaculo
                id = in.nextInt();
                vT = in.nextDouble();
                vN = in.nextDouble();
                d = in.nextDouble();
                alfa = in.nextDouble();
                r = in.nextDouble();
                // Crear el obstaculo con los datos leidos
                Obstaculo nuevo = new Obstaculo(id,r);
                nuevo.set(vT,vN,d,alfa);
                // Anadir el obstaculo a la lista
                lista.add(nuevo);
            }
        } catch (FileNotFoundException e) {
            System.out.println("No encuentro el fichero");
            // Error grave. Se abandona el programa
            System.exit(-1);
        }
    }
    
    /**
     * Retorna un array conteniendo todos los obstaculos para los que se 
     * detecta un posible choque
     * 
     * @return array con los obstaculos con los que es posible chocar
     */
    public Obstaculo[] posiblesChoques() {
	// hacer
	return null;
    }

    /**
     * Pone en pantalla un informe de todos los obstaculos
     */
    public void informe() {
	// hacer
    }
    
    /**
     * Busca en la lista el primer Obstaculo cuyo margen de alcance en
     * valor absoluto es menor o iguar que r+A y lo retorna.  Si no lo
     * encuentra lanza NoEncontrado.
     * 
     * @return primer obstaculo con poco margen de alcance
     */
    public Obstaculo pocoMargenAlcance() throws NoEncontrado {
	// hacer
        return null;
    }
    
    /**
     * Hace un dibujo esquematico de los obstaculos y del coche
     */
    public void dibujoEsquematico() {
	// Parte avanzada
    }
    
}
